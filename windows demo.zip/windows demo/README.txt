Advanced Technical Standard Defitition instalation instructions- Winows version:

Step 1) Download windows demmo.zip
Step 2) Unzip and open windows demmo.zip
Step 3) Search in your system for environment variables
Step 4) In system properties, click environment variables -> new
Step 5) Add ATSD to the environment variables, and make the value be the path to the file 
Step 6) Restart your computer
Step 7) Place all desired robots into the windows demmo folder
Step 8) Open STD
Step 9) Enjoy




Linux:

Step 1) Go to libsdl.org and download the latest package for your machine
Step 2) Follow the SDL instalation instructions at http://lazyfoo.net/tutorials/SDL/01_hello_SDL/linux/index.php
Step 3) in the command line, enter export ATSD=*Insert file path here*
Step 4) Go to the file containing the main.cpp
Step 5) Compile by using the command g++ main.cpp -w -lSDL2 -o main in the command line
Step 6) Run using the ./a.out command
Step 7) Enjoy