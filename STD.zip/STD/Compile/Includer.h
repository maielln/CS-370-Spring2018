#include <stdlib.h>
#include <iostream>
#include <cmath>
#include <string.h>
#include <ctime>
#include <stdio.h>
#include <string>
#include <iostream>
#include <vector>
#include <windows.h>
#include <sstream>


using namespace std;
