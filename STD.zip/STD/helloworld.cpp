#include <iostream>
#include <cstdlib>

using namespace std;
void world();

int main (void)
{


return 0;
}

void world() {


	printf("This function was called");

}
